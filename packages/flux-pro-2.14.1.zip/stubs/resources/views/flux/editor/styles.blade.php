@blaze

{!! app('flux')->editorStyles() !!}
